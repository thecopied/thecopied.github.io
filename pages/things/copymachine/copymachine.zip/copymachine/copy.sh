#!/bin/bash
cd copyrighted_material
i=0
while :
do
	for a in *; do
		if [ $a = 0 ]; then
			b=1
		else
			b=0
		fi
		cp $a $b && rm $a
	((i++))
	done
	echo $((150000 * $i)) 
done
